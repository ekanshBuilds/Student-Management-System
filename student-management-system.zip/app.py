
from flask import Flask, render_template, request, redirect, url_for
import sqlite3

app = Flask(__name__)
DATABASE = "students.db"

def init_db():
    conn = sqlite3.connect(DATABASE)
    conn.execute("""
    CREATE TABLE IF NOT EXISTS students(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        age INTEGER,
        course TEXT,
        email TEXT
    )
    """)
    conn.commit()
    conn.close()

init_db()

def get_db_connection():
    conn = sqlite3.connect(DATABASE)
    conn.row_factory = sqlite3.Row
    return conn

@app.route("/")
def index():
    conn = get_db_connection()
    students = conn.execute("SELECT * FROM students ORDER BY id DESC").fetchall()
    conn.close()
    return render_template("index.html", students=students)

@app.route("/add", methods=["GET","POST"])
def add_student():
    if request.method == "POST":
        conn = get_db_connection()
        conn.execute(
            "INSERT INTO students(name,age,course,email) VALUES(?,?,?,?)",
            (request.form["name"], request.form["age"], request.form["course"], request.form["email"])
        )
        conn.commit()
        conn.close()
        return redirect(url_for("index"))
    return render_template("add_student.html")

@app.route("/edit/<int:id>", methods=["GET","POST"])
def edit_student(id):
    conn = get_db_connection()
    student = conn.execute("SELECT * FROM students WHERE id=?", (id,)).fetchone()
    if request.method == "POST":
        conn.execute(
            "UPDATE students SET name=?, age=?, course=?, email=? WHERE id=?",
            (request.form["name"], request.form["age"], request.form["course"], request.form["email"], id)
        )
        conn.commit()
        conn.close()
        return redirect(url_for("index"))
    conn.close()
    return render_template("edit_student.html", student=student)

@app.route("/delete/<int:id>")
def delete_student(id):
    conn = get_db_connection()
    conn.execute("DELETE FROM students WHERE id=?", (id,))
    conn.commit()
    conn.close()
    return redirect(url_for("index"))

if __name__ == "__main__":
    app.run(debug=True)
